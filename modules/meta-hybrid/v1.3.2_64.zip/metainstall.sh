
export KSU_HAS_METAMODULE="true"
export KSU_METAMODULE="meta-hybrid"
BASE_DIR="/data/adb/meta-hybrid"
ui_print "- Using Hybrid Mount metainstall"
install_module
ui_print "- Installation complete"