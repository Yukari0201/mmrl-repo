MODDIR=${0%/*}

dir="/data/adb/hostsredirect"

[ ! -d "$dir" ] && mkdir -p "$dir"
